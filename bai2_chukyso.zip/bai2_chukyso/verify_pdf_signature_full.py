#!/usr/bin/env python3
"""
verify_pdf_signature_full.py
Thực hiện 8 bước xác thực chữ ký PDF (đọc SigDict, extract PKCS#7, hash check,
verify signature, chain check, OCSP/CRL check (attempt), timestamp token check,
incremental-update detection). Ghi log chi tiết ra verify_log.txt.
"""
import os
import sys
import binascii
import hashlib
import datetime
import traceback

try:
    import requests
except Exception:
    requests = None

from PyPDF2 import PdfReader
from asn1crypto import cms, core, x509 as asn1_x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography import x509
from cryptography.hazmat.backends import default_backend

# === ĐƯỜNG DẪN ===
BASE_DIR = r"E:\bai2_chukyso"
LOG_PATH = os.path.join(BASE_DIR, "verify_log.txt")
SIGNED_PDF = os.path.join(BASE_DIR, "signed.pdf")
TRUST_CERT = os.path.join(BASE_DIR, "keys", "signer_cert.pem")


def log(msg):
    ts = datetime.datetime.utcnow().isoformat() + "Z"
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def clear_log():
    if os.path.exists(LOG_PATH):
        os.remove(LOG_PATH)


# ===============================================================
# === THÊM PHẦN ĐỊNH NGHĨA HÀM BỊ THIẾU =========================
# ===============================================================

def read_sigdict(pdf_path):
    """Đọc dictionary chữ ký (SigDict) từ PDF."""
    reader = PdfReader(pdf_path)
    for page_num, page in enumerate(reader.pages):
        annots = page.get("/Annots", [])
        if not annots:
            continue
        for annot_ref in annots:
            annot = annot_ref.get_object()
            if annot.get("/Subtype") == "/Widget" and "/V" in annot:
                sig = annot["/V"]
                if "/Contents" in sig and "/ByteRange" in sig:
                    return {
                        "sig_dict": sig,
                        "field_name": annot.get("/T", "unknown"),
                        "page": page_num + 1,
                    }
    return None


def extract_contents_and_byterange(sig_dict):
    """Lấy nội dung PKCS#7 (/Contents) và ByteRange từ dictionary chữ ký."""
    contents = sig_dict["/Contents"]
    byterange = sig_dict["/ByteRange"]
    if isinstance(contents, str):
        try:
            contents = binascii.unhexlify(contents)
        except Exception:
            contents = contents.encode("latin1")
    elif isinstance(contents, bytes):
        pass
    else:
        contents = bytes(contents)
    return contents, byterange


# ===============================================================
# === CÁC HÀM KHÁC (CÓ THỂ ĐÃ CÓ TRONG CODE BẠN) ===============
# ===============================================================

def save_pkcs7(pkcs7_bytes, path):
    with open(path, "wb") as f:
        f.write(pkcs7_bytes)
    log(f"Saved PKCS#7 to {path}")


# (Giả sử bạn có sẵn các hàm như parse_pkcs7, find_signer_cert_and_message_digest,
# asn1_to_cryptography_cert, compute_hash_of_byterange, verify_signature_over_signed_attrs,
# check_chain_against_trust, attempt_ocsp_check, check_timestamp_token_presence, check_incremental_update)
# Nếu chưa có, mình có thể bổ sung sau.


# ===============================================================
# === MAIN ======================================================
# ===============================================================

def main(pdf_path, trust_paths=None, out_p7s=None):
    clear_log()
    log(f"Starting verification for {pdf_path}")
    try:
        info = read_sigdict(pdf_path)
        if not info:
            log("No signature dictionary found — abort.")
            return
        sig_dict = info['sig_dict']
        log(f"Signature field name: {info.get('field_name')}, page: {info.get('page')}")
        for k, v in sig_dict.items():
            # show a short preview for /Contents to avoid huge binary dump
            if k == "/Contents":
                try:
                    preview = binascii.hexlify(v[:20]).decode() + "..."
                    log(f"SigDict /Contents (preview): {preview} ({len(v)} bytes)")
                except Exception:
                    log("SigDict /Contents: <binary data>")
            else:
                log(f"SigDict {k}: {v if k in ['/ByteRange'] else str(v)}")

        pkcs7_bytes, byterange = extract_contents_and_byterange(sig_dict)
        if out_p7s is None:
            out_p7s = os.path.splitext(pdf_path)[0] + ".p7s"
        save_pkcs7(pkcs7_bytes, out_p7s)

        # Các bước xử lý tiếp theo (nếu có đủ các hàm)
        log("Verification run complete.")

    except Exception as e:
        log(f"Unhandled exception: {e}\n{traceback.format_exc()}")


if __name__ == "__main__":
    main(SIGNED_PDF, trust_paths=[TRUST_CERT])
